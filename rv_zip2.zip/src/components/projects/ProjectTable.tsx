import {
  ArrowUpRight,
} from "lucide-react";

import {
  Link,
} from "react-router-dom";

import type {
  ProjectListRow,
} from "../../types/projectAvailability";

import {
  formatHours,
  formatMonth,
} from "../../utils/formatters";

import {
  Card,
} from "../ui/Card";

interface ProjectTableProps {
  rows:
    ProjectListRow[];

  focusMonth: string;
}

function formatDateMonth(
  value: string,
): string {
  const match =
    /^(\d{4})-(\d{2})/.exec(
      value,
    );

  if (match === null) {
    return value;
  }

  return formatMonth(
    `${match[1]}-${match[2]}`,
  );
}

export function ProjectTable({
  rows,
  focusMonth,
}: ProjectTableProps) {
  return (
    <Card padding={false}>
      <div className="overflow-x-auto">
        <table className="min-w-[880px] w-full text-sm">
          <thead className="bg-slate-50">
            <tr>
              <Header>
                Project
              </Header>

              <Header>
                Proposal
              </Header>

              <Header>
                Status
              </Header>

              <Header>
                Start
              </Header>

              <Header>
                End
              </Header>

              <Header align="right">
                Resources
              </Header>

              <Header align="right">
                {formatMonth(
                  focusMonth,
                )} Effort
              </Header>
            </tr>
          </thead>

          <tbody className="divide-y divide-slate-100 bg-white">
            {rows.map(
              (row) => (
                <tr
                  key={
                    row.projectId
                  }
                  className="hover:bg-slate-50"
                >
                  <td className="px-5 py-3.5">
                    <Link
                      to={`/projects/${encodeURIComponent(
                        row.projectId,
                      )}`}
                      className="group inline-flex items-center gap-1 rounded outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
                    >
                      <span className="text-xs font-semibold text-slate-900 group-hover:text-blue-700">
                        {
                          row.projectName
                        }
                      </span>

                      <ArrowUpRight
                        className="size-3.5 text-slate-300 group-hover:text-blue-600"
                        aria-hidden="true"
                      />
                    </Link>
                  </td>

                  <td className="px-4 py-3.5 text-xs text-slate-500">
                    {
                      row.proposalNumber
                    }
                  </td>

                  <td className="px-4 py-3.5 text-xs font-medium text-slate-600">
                    {
                      row.projectStatus
                    }
                  </td>

                  <td className="px-4 py-3.5 text-xs text-slate-600">
                    {formatDateMonth(
                      row.startDate,
                    )}
                  </td>

                  <td className="px-4 py-3.5 text-xs text-slate-600">
                    {formatDateMonth(
                      row.endDate,
                    )}
                  </td>

                  <td className="px-4 py-3.5 text-right text-xs font-medium tabular-nums text-slate-700">
                    {row.resourceCount.toLocaleString(
                      "en-US",
                    )}
                  </td>

                  <td className="px-5 py-3.5 text-right text-xs font-semibold tabular-nums text-slate-900">
                    {formatHours(
                      row.focusMonthEffort,
                    )}
                  </td>
                </tr>
              ),
            )}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function Header({
  children,
  align = "left",
}: {
  children:
    React.ReactNode;

  align?: "left" | "right";
}) {
  return (
    <th
      className={`border-b border-slate-200 px-4 py-3 text-[10px] font-semibold uppercase tracking-wide text-slate-500 first:px-5 last:px-5 ${
        align === "right"
          ? "text-right"
          : "text-left"
      }`}
    >
      {children}
    </th>
  );
}