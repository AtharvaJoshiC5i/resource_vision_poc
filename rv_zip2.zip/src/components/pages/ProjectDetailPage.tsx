import {
  ArrowLeft,
  FolderSearch,
} from "lucide-react";

import {
  useMemo,
  useState,
} from "react";

import {
  Link,
  useParams,
} from "react-router-dom";

import {
  availabilityQueryContext,
} from "../../data";

import {
  POC_CURRENT_MONTH,
} from "../../constants/poc";

import {
  getProjectAvailabilityDetail,
} from "../../services/projectAvailabilityService";

import {
  addMonths,
  getMonthRange,
} from "../../services/monthService";

import {
  PlanningHorizonControl,
} from "../availability-overview/PlanningHorizonControl";

import {
  ProjectMonthlyEffortSummary,
} from "../projects/ProjectMonthlyEffortSummary";

import {
  ProjectResourceAllocationTable,
} from "../projects/ProjectResourceAllocationTable";

import {
  Card,
} from "../ui/Card";

import {
  EmptyState,
} from "../ui/EmptyState";

const PLANNING_HORIZON_MONTHS =
  4;

function hasCalendarCoverage(
  startMonth: string,
): boolean {
  const months =
    getMonthRange(
      startMonth,
      PLANNING_HORIZON_MONTHS,
    );

  const available =
    new Set(
      availabilityQueryContext.workCalendar.map(
        (record) =>
          record.monthKey,
      ),
    );

  return months.every(
    (month) =>
      available.has(
        month,
      ),
  );
}

function formatDate(
  value: string,
): string {
  const match =
    /^(\d{4})-(\d{2})-(\d{2})/.exec(
      value,
    );

  if (match === null) {
    return value;
  }

  return new Intl.DateTimeFormat(
    "en-US",
    {
      day: "numeric",
      month: "short",
      year: "numeric",
      timeZone: "UTC",
    },
  ).format(
    new Date(
      Date.UTC(
        Number(match[1]),
        Number(match[2]) - 1,
        Number(match[3]),
      ),
    ),
  );
}

export function ProjectDetailPage() {
  const {
    projectId,
  } =
    useParams<{
      projectId: string;
    }>();

  const decodedProjectId =
    projectId === undefined
      ? ""
      : decodeURIComponent(
          projectId,
        ).trim();

  const [
    startMonth,
    setStartMonth,
  ] = useState(
    POC_CURRENT_MONTH,
  );

  const monthKeys =
    useMemo(
      () =>
        getMonthRange(
          startMonth,
          PLANNING_HORIZON_MONTHS,
        ),
      [startMonth],
    );

  const detail =
    useMemo(
      () =>
        decodedProjectId ===
        ""
          ? null
          : getProjectAvailabilityDetail(
              availabilityQueryContext,
              decodedProjectId,
              startMonth,
              PLANNING_HORIZON_MONTHS,
            ),
      [
        decodedProjectId,
        startMonth,
      ],
    );

  const previousStart =
    addMonths(
      startMonth,
      -1,
    );

  const nextStart =
    addMonths(
      startMonth,
      1,
    );

  function handleHorizonChange(
    next: string,
  ) {
    if (
      !hasCalendarCoverage(
        next,
      )
    ) {
      return;
    }

    setStartMonth(next);
  }

  if (detail === null) {
    return (
      <div className="space-y-5">
        <Link
          to="/projects"
          className="inline-flex items-center gap-1.5 rounded text-xs font-medium text-slate-500 outline-none hover:text-blue-700 focus-visible:ring-2 focus-visible:ring-blue-600"
        >
          <ArrowLeft
            className="size-3.5"
            aria-hidden="true"
          />

          Back to Projects
        </Link>

        <Card padding={false}>
          <EmptyState
            icon={
              FolderSearch
            }
            title="Project not found"
            description="No project exists for this project ID."
          />
        </Card>
      </div>
    );
  }

  const {
    project,
  } = detail;

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-4 border-b border-slate-200 pb-5 lg:flex-row lg:items-end lg:justify-between">
        <div>
          <Link
            to="/projects"
            className="mb-3 inline-flex items-center gap-1.5 rounded text-xs font-medium text-slate-500 outline-none hover:text-blue-700 focus-visible:ring-2 focus-visible:ring-blue-600"
          >
            <ArrowLeft
              className="size-3.5"
              aria-hidden="true"
            />

            Back to Projects
          </Link>

          <div className="flex flex-wrap items-center gap-2">
            <h1 className="text-xl font-semibold tracking-tight text-slate-950">
              {
                project.projectName
              }
            </h1>

            <span className="rounded-md border border-slate-200 bg-slate-50 px-2 py-0.5 text-[10px] font-medium text-slate-600">
              {
                project.projectStatus
              }
            </span>
          </div>

          <p className="mt-1 text-xs text-slate-400">
            {
              project.proposalNumber
            }
          </p>

          <div className="mt-3 flex flex-wrap gap-x-6 gap-y-2 text-xs">
            <ProjectMeta
              label="Start"
              value={formatDate(
                project.startDate,
              )}
            />

            <ProjectMeta
              label="End"
              value={formatDate(
                project.endDate,
              )}
            />

            <ProjectMeta
              label="Assigned Resources"
              value={detail.uniqueResourceCount.toLocaleString(
                "en-US",
              )}
            />
          </div>
        </div>

        <PlanningHorizonControl
          startMonth={
            startMonth
          }
          numberOfMonths={
            PLANNING_HORIZON_MONTHS
          }
          onChange={
            handleHorizonChange
          }
          canGoPrevious={
            hasCalendarCoverage(
              previousStart,
            )
          }
          canGoNext={
            hasCalendarCoverage(
              nextStart,
            )
          }
        />
      </div>

      <ProjectMonthlyEffortSummary
        months={
          detail.monthlyEffort
        }
      />

      <ProjectResourceAllocationTable
        rows={
          detail.resources
        }
        monthKeys={
          monthKeys
        }
      />
    </div>
  );
}

function ProjectMeta({
  label,
  value,
}: {
  label: string;
  value: string;
}) {
  return (
    <div>
      <span className="text-slate-400">
        {label}
      </span>

      <span className="ml-1.5 font-medium text-slate-700">
        {value}
      </span>
    </div>
  );
}