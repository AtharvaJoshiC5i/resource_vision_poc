import { StrictMode } from "react";

import { createRoot } from "react-dom/client";

import { BrowserRouter } from "react-router-dom";

import App from "./App";
import "./index.css";

import { resourceMonthlyRecords, unassignedDemand } from "./data";

import { logDataValidation } from "./utils/validateData";

import { validateAvailabilityDomain } from "./utils/validateAvailabilityDomain";

import { validatePhase6, } from "./utils/validatePhase6";

import { validateAvailabilityV1, } from "./services/availabilityValidationService";

import {
  getResourceDiagnostics,
  logResourceDiagnostics,
} from "./utils/resourceDiagnostics";

if (import.meta.env.DEV) {
  /*
   * Validate the raw synthetic source contracts.
   */
  logDataValidation();

  /*
   * Validate the canonical Availability domain
   * independently of React.
   */
  validateAvailabilityDomain();

  /*
   * Existing POC diagnostics remain development-only.
   */
  const diagnostics = getResourceDiagnostics(
    resourceMonthlyRecords,
    unassignedDemand,
  );

  validatePhase6();

  validateAvailabilityV1();

  logResourceDiagnostics(diagnostics);
}

createRoot(document.getElementById("root")!).render(
  <StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </StrictMode>,
);
