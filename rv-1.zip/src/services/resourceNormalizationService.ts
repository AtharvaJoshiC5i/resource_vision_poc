import type { CapacityConfigRecord } from "../types/capacity";

import type { EmployeeMonthAvailability } from "../types/domain";

import type { FamstackRecord } from "../types/famstack";

import type { ProjectTrackRecord } from "../types/projectTrack";

import type { ResourceMonthlyRecord } from "../types/resourceMonthly";

import type { ZingHREmployee } from "../types/zinghr";

import { FAMSTACK_MONTHS, PROJECT_TRACK_MONTHS } from "../constants/poc";

import { normalizeEmployees } from "./normalization/employeeNormalizationService";

import { normalizeHistoricalAllocations } from "./normalization/famstackNormalizationService";

import {
  normalizeProjects,
  normalizeProjectTrackAllocations,
} from "./normalization/projectTrackNormalizationService";

import { normalizeWorkCalendar } from "./normalization/workCalendarNormalizationService";

import { getAvailabilityForRange } from "./availabilityQueryService";

const POC_MONTHS = [...FAMSTACK_MONTHS, ...PROJECT_TRACK_MONTHS];

export interface BuildResourceMonthlyRecordsInput {
  employees: ZingHREmployee[];

  famstackRecords: FamstackRecord[];

  projectTrackRecords: ProjectTrackRecord[];

  capacityConfig: CapacityConfigRecord[];
}

export function buildEmployeeMonthAvailabilities({
  employees,
  famstackRecords,
  projectTrackRecords,
  capacityConfig,
}: BuildResourceMonthlyRecordsInput): EmployeeMonthAvailability[] {
  const normalizedEmployees = normalizeEmployees(employees);

  const projects = normalizeProjects(projectTrackRecords);

  const historicalAllocations = normalizeHistoricalAllocations(famstackRecords);

  const plannedAllocations =
    normalizeProjectTrackAllocations(projectTrackRecords);

  const workCalendar = normalizeWorkCalendar(capacityConfig);

  /*
   * The current POC dataset spans Jan-Dec 2026.
   *
   * The underlying query service itself is not
   * restricted to 2026; later callers can request
   * arbitrary ranges as long as calendar/allocation
   * data exists for those months.
   */
  return getAvailabilityForRange(
    {
      employees: normalizedEmployees,

      projects,

      historicalAllocations,

      plannedAllocations,

      workCalendar,
    },

    POC_MONTHS[0],

    POC_MONTHS.length,
  );
}

/*
 * Compatibility adapter for the existing Parts 3-8 UI.
 *
 * EmployeeMonthAvailability remains the canonical
 * domain model underneath this view model.
 */
export function buildResourceMonthlyRecords(
  input: BuildResourceMonthlyRecordsInput,
): ResourceMonthlyRecord[] {
  return buildEmployeeMonthAvailabilities(input).map((availability) => ({
    employee_id: availability.employeeId,

    employee_name: availability.employeeName,

    primary_capability: availability.primaryCapability,

    secondary_capability: availability.secondaryCapability,

    department: availability.department,

    grade: availability.grade,

    location: availability.location,

    country: availability.country,

    month_key: availability.monthKey,

    total_capacity: availability.totalCapacityHours,

    utilized_capacity: availability.allocatedHours,

    available_capacity: availability.availableHours,

    utilization_percentage: availability.utilizationPercentage,

    availability_percentage: availability.availabilityPercentage,

    availability_status: availability.status,

    source: availability.source,
  }));
}
