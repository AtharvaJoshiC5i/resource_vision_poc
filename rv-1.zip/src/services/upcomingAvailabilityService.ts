import type {
  AvailabilityTransition,
  AvailabilityTransitionType,
  EmployeeMonthAvailability,
} from "../types/domain";

import { compareMonthKeys } from "./monthService";

function getTransitionTypes(
  previous: EmployeeMonthAvailability,

  current: EmployeeMonthAvailability,
): AvailabilityTransitionType[] {
  const types: AvailabilityTransitionType[] = [];

  if (current.availableHours > previous.availableHours) {
    types.push("GAINED_CAPACITY");
  }

  if (previous.status !== "AVAILABLE" && current.status === "AVAILABLE") {
    types.push("BECAME_FULLY_AVAILABLE");
  }

  if (
    previous.status === "FULLY_ALLOCATED" &&
    current.status === "PARTIALLY_AVAILABLE"
  ) {
    types.push("FULLY_ALLOCATED_TO_PARTIAL");
  }

  if (
    previous.status === "PARTIALLY_AVAILABLE" &&
    current.status === "AVAILABLE"
  ) {
    types.push("PARTIAL_TO_FULLY_AVAILABLE");
  }

  return types;
}

export function getUpcomingAvailabilityTransitions(
  records: EmployeeMonthAvailability[],
): AvailabilityTransition[] {
  const recordsByEmployee = new Map<string, EmployeeMonthAvailability[]>();

  for (const record of records) {
    const existing = recordsByEmployee.get(record.employeeId) ?? [];

    existing.push(record);

    recordsByEmployee.set(record.employeeId, existing);
  }

  const transitions: AvailabilityTransition[] = [];

  for (const employeeRecords of recordsByEmployee.values()) {
    const sorted = [...employeeRecords].sort((left, right) =>
      compareMonthKeys(left.monthKey, right.monthKey),
    );

    for (let index = 1; index < sorted.length; index += 1) {
      const previous = sorted[index - 1];

      const current = sorted[index];

      const transitionTypes = getTransitionTypes(previous, current);

      if (transitionTypes.length === 0) {
        continue;
      }

      transitions.push({
        employeeId: current.employeeId,

        employeeName: current.employeeName,

        fromMonthKey: previous.monthKey,

        toMonthKey: current.monthKey,

        fromStatus: previous.status,

        toStatus: current.status,

        previousAvailableHours: previous.availableHours,

        currentAvailableHours: current.availableHours,

        additionalAvailableHours:
          current.availableHours - previous.availableHours,

        transitionTypes,
      });
    }
  }

  return transitions.sort((left, right) => {
    const monthComparison = compareMonthKeys(left.toMonthKey, right.toMonthKey);

    if (monthComparison !== 0) {
      return monthComparison;
    }

    return right.additionalAvailableHours - left.additionalAvailableHours;
  });
}
