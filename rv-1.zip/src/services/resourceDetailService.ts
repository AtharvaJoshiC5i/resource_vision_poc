import type { FamstackRecord } from "../types/famstack";

import type { ProjectTrackRecord } from "../types/projectTrack";

import type { ResourceMonthlyRecord } from "../types/resourceMonthly";

import type { ZingHREmployee } from "../types/zinghr";

import type {
  HistoricalActivityRow,
  ResourceDetailViewModel,
  ResourceEmployeeDetail,
  ResourceProjectAllocation,
  ResourceReconciliationIssue,
} from "../types/resourceDetail";

import { POC_CURRENT_MONTH } from "../constants/poc";

const OUTLOOK_MONTHS = ["2026-09", "2026-10", "2026-11", "2026-12"];

function createEmployeeDetail(
  employee: ZingHREmployee,
): ResourceEmployeeDetail {
  return {
    employeeId: employee.employee_id,

    employeeName: employee.employee_name,

    primaryCapability: employee.primary_capability,

    secondaryCapability: employee.secondary_capability,

    department: employee.department,

    grade: employee.grade,

    location: employee.location,

    country: employee.country,

    employmentStatus: employee.employment_status,

    dateOfJoining: employee.date_of_joining,

    dateOfLeaving:
      employee.date_of_leaving.trim() === ""
        ? undefined
        : employee.date_of_leaving,
  };
}

export function getResourceTimeline(
  records: ResourceMonthlyRecord[],
  employeeId: string,
): ResourceMonthlyRecord[] {
  return records
    .filter((record) => record.employee_id === employeeId)
    .sort((left, right) => left.month_key.localeCompare(right.month_key));
}

export function getResourceOutlook(
  records: ResourceMonthlyRecord[],
  employeeId: string,
): ResourceMonthlyRecord[] {
  return records
    .filter(
      (record) =>
        record.employee_id === employeeId &&
        OUTLOOK_MONTHS.includes(record.month_key),
    )
    .sort((left, right) => left.month_key.localeCompare(right.month_key));
}

export function getFutureAllocations(
  records: ProjectTrackRecord[],
  employeeId: string,
): ResourceProjectAllocation[] {
  const employeeRecords = records.filter(
    (record) =>
      record.employee_id === employeeId &&
      record.employee_tagging === "TAGGED" &&
      record.month_key >= POC_CURRENT_MONTH,
  );

  const groups = new Map<string, ProjectTrackRecord[]>();

  for (const record of employeeRecords) {
    const key =
      record.project_id || record.proposal_number || record.project_name;

    const existing = groups.get(key) ?? [];

    existing.push(record);

    groups.set(key, existing);
  }

  return [...groups.values()]
    .map((projectRecords) => {
      const first = projectRecords[0];

      const monthTotals = new Map<string, number>();

      for (const record of projectRecords) {
        monthTotals.set(
          record.month_key,
          (monthTotals.get(record.month_key) ?? 0) + record.effort_value,
        );
      }

      const months = [...monthTotals.entries()]
        .map(([monthKey, effortHours]) => ({
          monthKey,
          effortHours,
        }))
        .sort((left, right) => left.monthKey.localeCompare(right.monthKey));

      return {
        projectId: first.project_id,

        proposalNumber: first.proposal_number,

        projectName: first.project_name,

        projectStatus: first.project_status,

        contractType: first.contract_type,

        months,

        totalEffortHours: months.reduce(
          (total, month) => total + month.effortHours,
          0,
        ),
      };
    })
    .sort((left, right) => left.projectName.localeCompare(right.projectName));
}

export function getHistoricalActivity(
  records: FamstackRecord[],
  employeeId: string,
): HistoricalActivityRow[] {
  return records
    .filter((record) => record.employee_id === employeeId)
    .map((record) => ({
      monthKey: record.month_key,

      projectId: record.project_id,

      projectName: record.project_name,

      workCategory: record.work_category,

      actualEffortHours: record.actual_effort_hours,
    }))
    .sort((left, right) => {
      const monthComparison = left.monthKey.localeCompare(right.monthKey);

      if (monthComparison !== 0) {
        return monthComparison;
      }

      return left.projectName.localeCompare(right.projectName);
    });
}

function getReconciliationIssues(
  employeeId: string,
  timeline: ResourceMonthlyRecord[],
  famstackRecords: FamstackRecord[],
  projectTrackRecords: ProjectTrackRecord[],
): ResourceReconciliationIssue[] {
  const issues: ResourceReconciliationIssue[] = [];

  for (const record of timeline) {
    let sourceUtilization = 0;

    if (record.source === "FAMSTACK") {
      sourceUtilization = famstackRecords
        .filter(
          (sourceRecord) =>
            sourceRecord.employee_id === employeeId &&
            sourceRecord.month_key === record.month_key,
        )
        .reduce(
          (total, sourceRecord) => total + sourceRecord.actual_effort_hours,
          0,
        );
    } else {
      sourceUtilization = projectTrackRecords
        .filter(
          (sourceRecord) =>
            sourceRecord.employee_id === employeeId &&
            sourceRecord.month_key === record.month_key &&
            sourceRecord.employee_tagging === "TAGGED",
        )
        .reduce((total, sourceRecord) => total + sourceRecord.effort_value, 0);
    }

    if (Math.abs(sourceUtilization - record.utilized_capacity) > 0.01) {
      issues.push({
        monthKey: record.month_key,

        source: record.source,

        normalizedUtilization: record.utilized_capacity,

        sourceUtilization,
      });
    }
  }

  return issues;
}

export interface GetResourceDetailInput {
  employeeId: string;

  employees: ZingHREmployee[];

  monthlyRecords: ResourceMonthlyRecord[];

  famstackRecords: FamstackRecord[];

  projectTrackRecords: ProjectTrackRecord[];
}

export function getResourceDetail({
  employeeId,
  employees,
  monthlyRecords,
  famstackRecords,
  projectTrackRecords,
}: GetResourceDetailInput): ResourceDetailViewModel | null {
  const employee = employees.find(
    (candidate) => candidate.employee_id === employeeId,
  );

  if (employee === undefined) {
    return null;
  }

  const timeline = getResourceTimeline(monthlyRecords, employeeId);

  const currentSnapshot =
    timeline.find((record) => record.month_key === POC_CURRENT_MONTH) ?? null;

  const outlook = getResourceOutlook(monthlyRecords, employeeId);

  const futureAllocations = getFutureAllocations(
    projectTrackRecords,
    employeeId,
  );

  const historicalActivity = getHistoricalActivity(famstackRecords, employeeId);

  const reconciliationIssues = getReconciliationIssues(
    employeeId,
    timeline,
    famstackRecords,
    projectTrackRecords,
  );

  return {
    employee: createEmployeeDetail(employee),

    currentSnapshot,
    timeline,
    outlook,
    futureAllocations,
    historicalActivity,
    reconciliationIssues,
  };
}

export function logResourceDetailReconciliation(
  detail: ResourceDetailViewModel,
): void {
  if (detail.reconciliationIssues.length === 0) {
    return;
  }

  for (const issue of detail.reconciliationIssues) {
    console.warn(
      `[Resource Vision] Resource reconciliation mismatch for ${detail.employee.employeeId}, ${issue.monthKey}. Normalized=${issue.normalizedUtilization}, ${issue.source}=${issue.sourceUtilization}.`,
    );
  }
}
