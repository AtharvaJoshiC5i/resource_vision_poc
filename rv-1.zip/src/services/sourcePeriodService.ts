import { POC_CURRENT_MONTH } from "../constants/poc";

import type { AllocationSource } from "../types/domain";

import { compareMonthKeys } from "./monthService";

/*
 * POC source-cutover rule:
 *
 * Before September 2026
 * → historical actuals / Famstack
 *
 * September 2026 onward
 * → current/future planned allocations /
 *   Project Track
 *
 * Keeping this here prevents future consumers
 * from scattering date comparisons throughout
 * the application.
 */
export function getSourceForMonth(monthKey: string): AllocationSource {
  return compareMonthKeys(monthKey, POC_CURRENT_MONTH) < 0
    ? "FAMSTACK"
    : "PROJECT_TRACK";
}
