import type { UnassignedDemandRecord } from "../types/demand";
import type { ResourceMonthlyRecord } from "../types/resourceMonthly";

import { aggregateResourceRecords } from "./aggregationService";

export interface OverviewSnapshot {
  monthKey: string;

  totalCapacity: number;
  utilizedCapacity: number;
  availableCapacity: number;

  utilizationPercentage: number;
  availabilityPercentage: number;

  activeResourceCount: number;
  availableResourceCount: number;

  unassignedDemandHours: number;
  unassignedDemandCount: number;
}

export interface MonthlyAvailabilityTrendItem {
  monthKey: string;

  totalCapacity: number;
  utilizedCapacity: number;
  availableCapacity: number;

  availabilityPercentage: number;
  utilizationPercentage: number;

  source: "FAMSTACK" | "PROJECT_TRACK";
}

export interface CapabilityAvailabilityItem {
  primaryCapability: string;

  totalCapacity: number;
  utilizedCapacity: number;
  availableCapacity: number;

  availabilityPercentage: number;
  utilizationPercentage: number;

  resourceCount: number;
}

export interface CapacityOutlookRow {
  primaryCapability: string;

  months: Record<
    string,
    {
      totalCapacity: number;
      utilizedCapacity: number;
      availableCapacity: number;
      availabilityPercentage: number;
    }
  >;
}

export const POC_MONTH_OPTIONS = [
  "2026-01",
  "2026-02",
  "2026-03",
  "2026-04",
  "2026-05",
  "2026-06",
  "2026-07",
  "2026-08",
  "2026-09",
  "2026-10",
  "2026-11",
  "2026-12",
] as const;

export const PLANNING_MONTHS = [
  "2026-09",
  "2026-10",
  "2026-11",
  "2026-12",
] as const;

function getMonthRecords(
  records: ResourceMonthlyRecord[],
  monthKey: string,
): ResourceMonthlyRecord[] {
  return records.filter((record) => record.month_key === monthKey);
}

export function getOverviewSnapshot(
  records: ResourceMonthlyRecord[],
  demandRecords: UnassignedDemandRecord[],
  monthKey: string,
): OverviewSnapshot {
  const monthRecords = getMonthRecords(records, monthKey);

  const aggregate = aggregateResourceRecords(monthRecords);

  const monthlyDemand = getMonthlyUnassignedDemand(demandRecords, monthKey);

  const unassignedDemandHours = monthlyDemand.reduce(
    (total, demand) => total + demand.effort_hours,
    0,
  );

  return {
    monthKey,

    totalCapacity: aggregate.totalCapacity,

    utilizedCapacity: aggregate.utilizedCapacity,

    availableCapacity: aggregate.availableCapacity,

    utilizationPercentage: aggregate.utilizationPercentage,

    availabilityPercentage: aggregate.availabilityPercentage,

    activeResourceCount: monthRecords.length,

    availableResourceCount: monthRecords.filter(
      (record) => record.available_capacity > 0,
    ).length,

    unassignedDemandHours,
    unassignedDemandCount: monthlyDemand.length,
  };
}

export function getMonthlyAvailabilityTrend(
  records: ResourceMonthlyRecord[],
): MonthlyAvailabilityTrendItem[] {
  return POC_MONTH_OPTIONS.map((monthKey) => {
    const monthRecords = getMonthRecords(records, monthKey);

    const aggregate = aggregateResourceRecords(monthRecords);

    const source = monthKey < "2026-09" ? "FAMSTACK" : "PROJECT_TRACK";

    return {
      monthKey,

      totalCapacity: aggregate.totalCapacity,

      utilizedCapacity: aggregate.utilizedCapacity,

      availableCapacity: aggregate.availableCapacity,

      availabilityPercentage: aggregate.availabilityPercentage,

      utilizationPercentage: aggregate.utilizationPercentage,

      source,
    };
  });
}

export function getCapabilityAvailability(
  records: ResourceMonthlyRecord[],
  monthKey: string,
): CapabilityAvailabilityItem[] {
  const monthRecords = getMonthRecords(records, monthKey);

  const groups = new Map<string, ResourceMonthlyRecord[]>();

  for (const record of monthRecords) {
    const existing = groups.get(record.primary_capability) ?? [];

    existing.push(record);

    groups.set(record.primary_capability, existing);
  }

  return [...groups.entries()]
    .map(([primaryCapability, capabilityRecords]) => {
      const aggregate = aggregateResourceRecords(capabilityRecords);

      return {
        primaryCapability,

        totalCapacity: aggregate.totalCapacity,

        utilizedCapacity: aggregate.utilizedCapacity,

        availableCapacity: aggregate.availableCapacity,

        availabilityPercentage: aggregate.availabilityPercentage,

        utilizationPercentage: aggregate.utilizationPercentage,

        resourceCount: capabilityRecords.length,
      };
    })
    .sort(
      (left, right) =>
        left.availabilityPercentage - right.availabilityPercentage,
    );
}

export function getCapacityOutlook(
  records: ResourceMonthlyRecord[],
): CapacityOutlookRow[] {
  const capabilityNames = [
    ...new Set(records.map((record) => record.primary_capability)),
  ].sort((a, b) => a.localeCompare(b));

  return capabilityNames.map((primaryCapability) => {
    const months: CapacityOutlookRow["months"] = {};

    for (const monthKey of PLANNING_MONTHS) {
      const monthRecords = records.filter(
        (record) =>
          record.month_key === monthKey &&
          record.primary_capability === primaryCapability,
      );

      const aggregate = aggregateResourceRecords(monthRecords);

      months[monthKey] = {
        totalCapacity: aggregate.totalCapacity,

        utilizedCapacity: aggregate.utilizedCapacity,

        availableCapacity: aggregate.availableCapacity,

        availabilityPercentage: aggregate.availabilityPercentage,
      };
    }

    return {
      primaryCapability,
      months,
    };
  });
}

export function getMonthlyUnassignedDemand(
  demandRecords: UnassignedDemandRecord[],
  monthKey: string,
): UnassignedDemandRecord[] {
  return demandRecords.filter((record) => record.month_key === monthKey);
}
