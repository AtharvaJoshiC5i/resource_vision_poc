import type { MonthlyAvailabilitySummary } from "../../types/domain";

import { formatHours, formatMonth } from "../../utils/formatters";

import { Card } from "../ui/Card";

interface ForwardAvailabilityProps {
  summaries: MonthlyAvailabilitySummary[];

  selectedMonth: string;

  onSelectMonth: (monthKey: string) => void;
}

export function ForwardAvailability({
  summaries,
  selectedMonth,
  onSelectMonth,
}: ForwardAvailabilityProps) {
  return (
    <Card padding={false}>
      <div className="border-b border-slate-200 px-5 py-4">
        <h2 className="text-sm font-semibold text-slate-900">
          Forward Availability
        </h2>

        <p className="mt-1 text-xs leading-5 text-slate-500">
          Month-by-month workforce capacity across the planning horizon.
        </p>
      </div>

      <div className="overflow-x-auto">
        <div className="min-w-[760px]">
          <div className="grid grid-cols-[180px_repeat(4,minmax(140px,1fr))]">
            <div className="border-b border-r border-slate-200 bg-slate-50 px-4 py-3" />

            {summaries.map((summary) => {
              const selected = summary.monthKey === selectedMonth;

              return (
                <button
                  key={summary.monthKey}
                  type="button"
                  onClick={() => onSelectMonth(summary.monthKey)}
                  aria-pressed={selected}
                  className={`border-b border-r border-slate-200 px-4 py-3 text-center outline-none transition-colors last:border-r-0 focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-blue-600 ${
                    selected ? "bg-blue-50" : "bg-slate-50 hover:bg-slate-100"
                  }`}
                >
                  <span
                    className={`text-xs font-semibold ${
                      selected ? "text-blue-700" : "text-slate-700"
                    }`}
                  >
                    {formatMonth(summary.monthKey)}
                  </span>
                </button>
              );
            })}

            <MetricLabel>With Capacity</MetricLabel>

            {summaries.map((summary) => (
              <MetricValue
                key={`capacity-${summary.monthKey}`}
                selected={summary.monthKey === selectedMonth}
              >
                {summary.resourcesWithCapacity.toLocaleString("en-US")}
              </MetricValue>
            ))}

            <MetricLabel>Available Hours</MetricLabel>

            {summaries.map((summary) => (
              <MetricValue
                key={`hours-${summary.monthKey}`}
                selected={summary.monthKey === selectedMonth}
                emphasis
              >
                {formatHours(summary.totalAvailableHours)}
              </MetricValue>
            ))}

            <MetricLabel>Fully Allocated</MetricLabel>

            {summaries.map((summary) => (
              <MetricValue
                key={`allocated-${summary.monthKey}`}
                selected={summary.monthKey === selectedMonth}
              >
                {summary.fullyAllocatedResources.toLocaleString("en-US")}
              </MetricValue>
            ))}

            <MetricLabel>Over-Allocated</MetricLabel>

            {summaries.map((summary) => (
              <MetricValue
                key={`over-${summary.monthKey}`}
                selected={summary.monthKey === selectedMonth}
                attention={summary.overAllocatedResources > 0}
              >
                {summary.overAllocatedResources.toLocaleString("en-US")}
              </MetricValue>
            ))}
          </div>
        </div>
      </div>
    </Card>
  );
}

function MetricLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center border-b border-r border-slate-100 bg-white px-4 py-3 text-xs font-medium text-slate-500">
      {children}
    </div>
  );
}

function MetricValue({
  children,
  selected,
  emphasis = false,
  attention = false,
}: {
  children: React.ReactNode;
  selected: boolean;
  emphasis?: boolean;
  attention?: boolean;
}) {
  return (
    <div
      className={`flex items-center justify-end border-b border-r border-slate-100 px-4 py-3 text-right last:border-r-0 ${
        selected ? "bg-blue-50/50" : "bg-white"
      }`}
    >
      <span
        className={`text-sm ${
          attention
            ? "font-semibold text-red-700"
            : emphasis
              ? "font-semibold text-slate-900"
              : "font-medium text-slate-700"
        }`}
      >
        {children}
      </span>
    </div>
  );
}
