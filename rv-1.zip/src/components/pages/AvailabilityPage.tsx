import {
  useMemo,
  useState,
} from "react";

import {
  useLocation,
} from "react-router-dom";

import {
  CalendarRange,
} from "lucide-react";

import {
  availabilityQueryContext,
} from "../../data";

import {
  POC_CURRENT_MONTH,
} from "../../constants/poc";

import {
  getAvailabilityForRange,
} from "../../services/availabilityQueryService";

import {
  getMonthlyAvailabilitySummary,
} from "../../services/availabilityAggregationService";

import {
  aggregateAvailabilityByDimension,
} from "../../services/availabilityDimensionService";

import {
  getUpcomingAvailabilityTransitions,
} from "../../services/upcomingAvailabilityService";

import {
  getUpcomingAvailabilityMonthSummaries,
  getAvailabilityAttentionItems,
} from "../../services/availabilityAttentionService";

import {
  getResourceFilterOptions,
  getFilteredAvailabilityPopulation,
} from "../../services/resourceFilterService";

import {
  addMonths,
  getMonthRange,
} from "../../services/monthService";

import type {
  ResourceDimension,
} from "../../types/resourceFilters";

import {
  useResourceFilters,
} from "../../hooks/useResourceFilters";

import {
  AvailabilitySummaryCards,
} from "../availability-overview/AvailabilitySummaryCards";

import {
  CapacitySummary,
} from "../availability-overview/CapacitySummary";

import {
  ForwardAvailability,
} from "../availability-overview/ForwardAvailability";

import {
  PlanningHorizonControl,
} from "../availability-overview/PlanningHorizonControl";

import {
  UpcomingAvailability,
} from "../availability-overview/UpcomingAvailability";

import {
  UpcomingResourceList,
} from "../availability-overview/UpcomingResourceList";

import {
  AvailabilityAttention,
} from "../availability-overview/AvailabilityAttention";

import {
  UpcomingResourcePreview,
} from "../availability-overview/UpcomingResourcePreview";

import {
  ActiveFilterSummary,
} from "../availability-filters/ActiveFilterSummary";

import {
  AvailabilityDimensionSummary,
} from "../availability-filters/AvailabilityDimensionSummary";

import {
  ResourceFilterBar,
} from "../availability-filters/ResourceFilterBar";

import {
  Card,
} from "../ui/Card";

import {
  EmptyState,
} from "../ui/EmptyState";

import {
  PageHeader,
} from "../ui/PageHeader";

const PLANNING_HORIZON_MONTHS =
  4;

function hasCalendarCoverage(
  startMonth: string,
): boolean {
  const requestedMonths =
    getMonthRange(
      startMonth,
      PLANNING_HORIZON_MONTHS,
    );

  const availableMonths =
    new Set(
      availabilityQueryContext.workCalendar.map(
        (record) =>
          record.monthKey,
      ),
    );

  return requestedMonths.every(
    (monthKey) =>
      availableMonths.has(
        monthKey,
      ),
  );
}

export function AvailabilityPage() {
  const location =
    useLocation();

  const [
    startMonth,
    setStartMonth,
  ] = useState(
    POC_CURRENT_MONTH,
  );

  const [
    groupBy,
    setGroupBy,
  ] =
    useState<ResourceDimension>(
      "primaryCapability",
    );

  const {
    filters,
    setFilters,
    clearAll,
    removeDimensionValue,
  } = useResourceFilters(
    startMonth,
  );

  const resourcesHref =
    `/resources${location.search}`;

  const monthKeys =
    useMemo(
      () =>
        getMonthRange(
          startMonth,
          PLANNING_HORIZON_MONTHS,
        ),
      [startMonth],
    );

  const effectiveFocusMonth =
    monthKeys.includes(
      filters.focusMonth,
    )
      ? filters.focusMonth
      : monthKeys[0];

  const effectiveFilters =
    useMemo(
      () => ({
        ...filters,

        focusMonth:
          effectiveFocusMonth,
      }),
      [
        filters,
        effectiveFocusMonth,
      ],
    );

  /*
   * Calculate the planning-horizon dataset once.
   * Everything below is a derived selector/view.
   */
  const allRangeRecords =
    useMemo(
      () =>
        getAvailabilityForRange(
          availabilityQueryContext,
          startMonth,
          PLANNING_HORIZON_MONTHS,
        ),
      [startMonth],
    );

  const filteredRecords =
    useMemo(
      () =>
        getFilteredAvailabilityPopulation(
          allRangeRecords,
          availabilityQueryContext.employees,
          effectiveFilters,
        ),
      [
        allRangeRecords,
        effectiveFilters,
      ],
    );

  const filterOptions =
    useMemo(
      () =>
        getResourceFilterOptions(
          availabilityQueryContext.employees,
          effectiveFilters,
        ),
      [effectiveFilters],
    );

  const summaries =
    useMemo(
      () =>
        monthKeys.map(
          (monthKey) =>
            getMonthlyAvailabilitySummary(
              filteredRecords,
              monthKey,
            ),
        ),
      [
        filteredRecords,
        monthKeys,
      ],
    );

  const selectedSummary =
    useMemo(
      () =>
        summaries.find(
          (summary) =>
            summary.monthKey ===
            effectiveFocusMonth,
        ) ??
        summaries[0] ??
        null,
      [
        summaries,
        effectiveFocusMonth,
      ],
    );

  const selectedRecords =
    useMemo(
      () =>
        selectedSummary === null
          ? []
          : filteredRecords.filter(
              (record) =>
                record.monthKey ===
                selectedSummary.monthKey,
            ),
      [
        filteredRecords,
        selectedSummary,
      ],
    );

  const transitions =
    useMemo(
      () =>
        getUpcomingAvailabilityTransitions(
          filteredRecords,
        ),
      [filteredRecords],
    );

  const upcomingSummaries =
    useMemo(
      () =>
        getUpcomingAvailabilityMonthSummaries(
          filteredRecords,
        ),
      [filteredRecords],
    );

  const attentionItems =
    useMemo(
      () =>
        getAvailabilityAttentionItems(
          filteredRecords,
        ),
      [filteredRecords],
    );

  const dimensionRows =
    useMemo(
      () =>
        selectedSummary === null
          ? []
          : aggregateAvailabilityByDimension(
              filteredRecords,
              groupBy,
              selectedSummary.monthKey,
            ),
      [
        filteredRecords,
        groupBy,
        selectedSummary,
      ],
    );

  const previousStart =
    addMonths(
      startMonth,
      -1,
    );

  const nextStart =
    addMonths(
      startMonth,
      1,
    );

  function handleHorizonChange(
    next: string,
  ) {
    if (
      !hasCalendarCoverage(
        next,
      )
    ) {
      return;
    }

    setStartMonth(next);

    setFilters({
      ...filters,

      focusMonth: next,
    });
  }

  function handleFocusMonthChange(
    monthKey: string,
  ) {
    setFilters({
      ...filters,

      focusMonth:
        monthKey,
    });
  }

  function handleDimensionSelection(
    dimension:
      ResourceDimension,

    value: string,
  ) {
    const existing =
      filters[dimension];

    if (
      existing.includes(value)
    ) {
      return;
    }

    setFilters({
      ...filters,

      [dimension]: [
        ...existing,
        value,
      ],
    });
  }

  const hasAvailabilityData =
    allRangeRecords.length >
    0;

  const hasFilteredResources =
    filteredRecords.length >
    0;

  return (
    <div className="space-y-5">
      <PageHeader
        title="Resource Availability"
        description="Current and forward-looking workforce capacity."
        actions={
          <PlanningHorizonControl
            startMonth={
              startMonth
            }
            numberOfMonths={
              PLANNING_HORIZON_MONTHS
            }
            onChange={
              handleHorizonChange
            }
            canGoPrevious={
              hasCalendarCoverage(
                previousStart,
              )
            }
            canGoNext={
              hasCalendarCoverage(
                nextStart,
              )
            }
          />
        }
      />

      <ResourceFilterBar
        filters={
          effectiveFilters
        }
        options={
          filterOptions
        }
        monthKeys={
          monthKeys
        }
        onFiltersChange={
          setFilters
        }
        onClearAll={
          clearAll
        }
      />

      <ActiveFilterSummary
        filters={
          effectiveFilters
        }
        onRemoveDimensionValue={
          removeDimensionValue
        }
        onClearStatus={() =>
          setFilters({
            ...filters,

            availabilityStatus:
              [],
          })
        }
        onClearSearch={() =>
          setFilters({
            ...filters,

            search: "",
          })
        }
        onClearAll={
          clearAll
        }
      />

      {!hasAvailabilityData ? (
        <Card padding={false}>
          <EmptyState
            icon={
              CalendarRange
            }
            title="No resource availability data"
            description="No availability data exists for this planning horizon."
          />
        </Card>
      ) : !hasFilteredResources ? (
        <Card padding={false}>
          <EmptyState
            icon={
              CalendarRange
            }
            title="No resources match the current filters"
            description="Clear or adjust the active filters to restore resource availability data."
          />

          <div className="flex justify-center border-t border-slate-100 px-5 py-4">
            <button
              type="button"
              onClick={
                clearAll
              }
              className="rounded-lg bg-blue-600 px-3.5 py-2 text-sm font-medium text-white outline-none hover:bg-blue-700 focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
            >
              Clear filters
            </button>
          </div>
        </Card>
      ) : selectedSummary ===
        null ? (
        <Card padding={false}>
          <EmptyState
            icon={
              CalendarRange
            }
            title="No availability summary"
            description="Availability summary data could not be generated for this planning horizon."
          />
        </Card>
      ) : (
        <>
          <AvailabilitySummaryCards
            summary={
              selectedSummary
            }
          />

          <ForwardAvailability
            summaries={
              summaries
            }
            selectedMonth={
              selectedSummary.monthKey
            }
            onSelectMonth={
              handleFocusMonthChange
            }
          />

          <AvailabilityDimensionSummary
            dimension={
              groupBy
            }
            monthKey={
              selectedSummary.monthKey
            }
            rows={
              dimensionRows
            }
            onDimensionChange={
              setGroupBy
            }
            onSelectValue={
              handleDimensionSelection
            }
          />

          <div className="grid gap-5 xl:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
            <CapacitySummary
              summary={
                selectedSummary
              }
              records={
                selectedRecords
              }
            />

            <UpcomingAvailability
              summaries={
                upcomingSummaries
              }
            />
          </div>

          <UpcomingResourceList
            transitions={
              transitions
            }
          />

          <AvailabilityAttention
            items={
              attentionItems
            }
          />

          <UpcomingResourcePreview
            records={
              filteredRecords
            }
            resourcesHref={
              resourcesHref
            }
          />
        </>
      )}
    </div>
  );
}