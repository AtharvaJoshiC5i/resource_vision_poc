import { capacityConfig, famstack, projectTrack, zinghr } from "../data";

import { FAMSTACK_MONTHS, PROJECT_TRACK_MONTHS } from "../constants/poc";

export interface ValidationReport {
  isValid: boolean;
  errors: string[];
  warnings: string[];
}

const REQUIRED_ZINGHR_STRING_FIELDS = [
  "employee_id",
  "employee_name",
  "email",
  "primary_capability",
  "secondary_capability",
  "department",
  "grade",
  "location",
  "country",
  "employment_status",
  "date_of_joining",
] as const;

function getCapacityKey(
  country: string,
  location: string,
  monthKey: string,
): string {
  return `${country}::${location}::${monthKey}`;
}

export function validateData(): ValidationReport {
  const errors: string[] = [];
  const warnings: string[] = [];

  const employeeIds = new Set<string>();

  for (const employee of zinghr) {
    if (employeeIds.has(employee.employee_id)) {
      errors.push(
        `Duplicate ZingHR employee_id found: ${employee.employee_id}`,
      );
    }

    employeeIds.add(employee.employee_id);

    for (const field of REQUIRED_ZINGHR_STRING_FIELDS) {
      if (employee[field].trim() === "") {
        errors.push(
          `ZingHR employee ${employee.employee_id || "(blank employee_id)"} is missing required field: ${field}`,
        );
      }
    }

    if (employee.weekly_capacity_hours <= 0) {
      errors.push(
        `ZingHR employee ${employee.employee_id} has invalid weekly_capacity_hours: ${employee.weekly_capacity_hours}`,
      );
    }
  }

  const expectedFamstackMonths = new Set<string>(FAMSTACK_MONTHS);

  for (const record of famstack) {
    if (!employeeIds.has(record.employee_id)) {
      errors.push(
        `Famstack record references unknown employee_id ${record.employee_id} for month ${record.month_key}.`,
      );
    }

    if (!expectedFamstackMonths.has(record.month_key)) {
      errors.push(
        `Famstack record for employee ${record.employee_id} has unexpected month ${record.month_key}.`,
      );
    }
  }

  const expectedProjectTrackMonths = new Set<string>(PROJECT_TRACK_MONTHS);

  for (const record of projectTrack) {
    if (!expectedProjectTrackMonths.has(record.month_key)) {
      errors.push(
        `Project Track record ${record.project_id} has unexpected month ${record.month_key}.`,
      );
    }

    if (record.employee_tagging === "UNASSIGNED_GRADE_DEMAND") {
      if (record.employee_id !== "") {
        errors.push(
          `Unassigned demand record ${record.project_id} for ${record.month_key} unexpectedly contains employee_id ${record.employee_id}.`,
        );
      }

      if (record.employee_name !== "") {
        errors.push(
          `Unassigned demand record ${record.project_id} for ${record.month_key} unexpectedly contains employee_name ${record.employee_name}.`,
        );
      }

      continue;
    }

    if (record.employee_id.trim() === "") {
      errors.push(
        `Project Track record ${record.project_id} for ${record.month_key} is tagged as ${record.employee_tagging} but has no employee_id.`,
      );

      continue;
    }

    if (!employeeIds.has(record.employee_id)) {
      errors.push(
        `Project Track record ${record.project_id} references unknown employee_id ${record.employee_id}.`,
      );
    }
  }

  const capacityKeys = new Set<string>();

  for (const record of capacityConfig) {
    const key = getCapacityKey(
      record.country,
      record.location,
      record.month_key,
    );

    if (capacityKeys.has(key)) {
      errors.push(
        `Duplicate capacity configuration found for ${record.country}, ${record.location}, ${record.month_key}.`,
      );
    }

    capacityKeys.add(key);

    const calculatedCapacity = record.working_days * record.hours_per_day;

    if (calculatedCapacity !== record.standard_capacity_hours) {
      errors.push(
        `Capacity configuration mismatch for ${record.country}, ${record.location}, ${record.month_key}: working_days × hours_per_day = ${calculatedCapacity}, but standard_capacity_hours = ${record.standard_capacity_hours}.`,
      );
    }
  }

  const allRequiredMonths = [...FAMSTACK_MONTHS, ...PROJECT_TRACK_MONTHS];

  for (const employee of zinghr) {
    for (const monthKey of allRequiredMonths) {
      const capacityKey = getCapacityKey(
        employee.country,
        employee.location,
        monthKey,
      );

      if (!capacityKeys.has(capacityKey)) {
        errors.push(
          `Missing capacity configuration for employee ${employee.employee_id}: ${employee.country}, ${employee.location}, ${monthKey}.`,
        );
      }
    }
  }

  const unassignedDemandCount = projectTrack.filter(
    (record) => record.employee_tagging === "UNASSIGNED_GRADE_DEMAND",
  ).length;

  if (unassignedDemandCount === 0) {
    warnings.push(
      "No UNASSIGNED_GRADE_DEMAND records were found in Project Track.",
    );
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings,
  };
}

export function logDataValidation(): void {
  const report = validateData();

  if (report.isValid) {
    console.info("[Resource Vision] Synthetic source data validation passed.");
  } else {
    console.error("[Resource Vision] Synthetic source data validation failed.");

    for (const error of report.errors) {
      console.error(`[Resource Vision] ${error}`);
    }
  }

  for (const warning of report.warnings) {
    console.warn(`[Resource Vision] ${warning}`);
  }
}
