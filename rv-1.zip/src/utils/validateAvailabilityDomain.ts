import type {
  Allocation,
  Employee,
  Project,
  WorkCalendar,
} from "../types/domain";

import { calculateEmployeeMonthAvailability } from "../services/availabilityService";

import { getAvailabilityForRange } from "../services/availabilityQueryService";

import { getMonthRange } from "../services/monthService";

import { getUpcomingAvailabilityTransitions } from "../services/upcomingAvailabilityService";

const baseEmployee: Employee = {
  employeeId: "VALIDATION_EMP",

  employeeName: "Validation Employee",

  employeeStatus: "ACTIVE",

  dateOfJoining: "2020-01-01",

  primaryCapability: "Validation",

  secondaryCapability: "Validation",

  department: "Validation",

  grade: "Validation",

  location: "Validation",

  country: "Validation",

  ftePercentage: 1,
};

const projects: Project[] = [
  {
    projectId: "A",
    proposalNumber: "A",
    projectName: "Project Alpha",
    projectStatus: "Active",
    startDate: "2026-01-01",
    endDate: "2027-12-31",
  },

  {
    projectId: "B",
    proposalNumber: "B",
    projectName: "Project Beta",
    projectStatus: "Active",
    startDate: "2026-01-01",
    endDate: "2027-12-31",
  },
];

function calendar(monthKey: string, workingDays: number): WorkCalendar {
  return {
    country: "Validation",

    location: "Validation",

    monthKey,

    workingDays,

    hoursPerDay: 8,

    monthlyCapacity: workingDays * 8,
  };
}

function allocation(
  projectId: string,
  monthKey: string,
  allocatedHours: number,
): Allocation {
  return {
    employeeId: baseEmployee.employeeId,

    projectId,

    monthKey,

    allocatedHours,

    source: "PROJECT_TRACK",
  };
}

function assert(condition: boolean, message: string): void {
  if (!condition) {
    throw new Error(
      `[Resource Vision] Availability domain validation failed: ${message}`,
    );
  }
}

function assertClose(actual: number, expected: number, message: string): void {
  assert(
    Math.abs(actual - expected) < 0.001,

    `${message}. Expected ${expected}, received ${actual}.`,
  );
}

export function validateAvailabilityDomain(): void {
  /*
   * CASE 1 — FULLY AVAILABLE
   */
  const fullyAvailable = calculateEmployeeMonthAvailability({
    employee: baseEmployee,

    monthKey: "2026-10",

    workCalendar: calendar("2026-10", 22),

    allocations: [],

    projects,
  });

  assert(
    fullyAvailable.allocatedHours === 0,

    "Case 1 allocated hours",
  );

  assert(
    fullyAvailable.availableHours === 176,

    "Case 1 available hours",
  );

  assert(
    fullyAvailable.blockedHours === 0,

    "Case 1 blocked hours",
  );

  assert(
    fullyAvailable.availableToPromiseHours === 176,

    "Case 1 available-to-promise",
  );

  assertClose(
    fullyAvailable.availabilityPercentage,

    100,

    "Case 1 availability percentage",
  );

  assert(
    fullyAvailable.status === "AVAILABLE",

    "Case 1 status",
  );

  /*
   * CASE 2 — PARTIAL / MULTIPLE PROJECTS
   */
  const partial = calculateEmployeeMonthAvailability({
    employee: baseEmployee,

    monthKey: "2026-10",

    workCalendar: calendar("2026-10", 22),

    allocations: [
      allocation("A", "2026-10", 80),

      allocation("B", "2026-10", 40),
    ],

    projects,
  });

  assert(
    partial.allocatedHours === 120,

    "Case 2 allocated hours",
  );

  assert(
    partial.availableHours === 56,

    "Case 2 available hours",
  );

  assert(
    partial.availableToPromiseHours === 56,

    "Case 2 available-to-promise",
  );

  assertClose(
    partial.availabilityPercentage,

    (56 / 176) * 100,

    "Case 2 availability percentage",
  );

  assert(
    partial.status === "PARTIALLY_AVAILABLE",

    "Case 2 status",
  );

  assert(
    partial.projectAllocations.length === 2,

    "Case 2 project breakdown",
  );

  /*
   * CASE 3 — FULLY ALLOCATED
   */
  const fullyAllocated = calculateEmployeeMonthAvailability({
    employee: baseEmployee,

    monthKey: "2026-10",

    workCalendar: calendar("2026-10", 22),

    allocations: [allocation("A", "2026-10", 176)],

    projects,
  });

  assert(
    fullyAllocated.availableHours === 0,

    "Case 3 available hours",
  );

  assertClose(
    fullyAllocated.availabilityPercentage,

    0,

    "Case 3 availability percentage",
  );

  assert(
    fullyAllocated.status === "FULLY_ALLOCATED",

    "Case 3 status",
  );

  /*
   * CASE 4 — OVER ALLOCATED
   */
  const overAllocated = calculateEmployeeMonthAvailability({
    employee: baseEmployee,

    monthKey: "2026-10",

    workCalendar: calendar("2026-10", 22),

    allocations: [allocation("A", "2026-10", 200)],

    projects,
  });

  assert(
    overAllocated.availableHours === -24,

    "Case 4 available hours",
  );

  assert(
    overAllocated.availabilityPercentage < 0,

    "Case 4 availability percentage should remain negative",
  );

  assert(
    overAllocated.status === "OVER_ALLOCATED",

    "Case 4 status",
  );

  /*
   * CASE 5 — DIFFERENT MONTH CAPACITY
   */
  const november = calculateEmployeeMonthAvailability({
    employee: baseEmployee,

    monthKey: "2026-11",

    workCalendar: calendar("2026-11", 20),

    allocations: [allocation("A", "2026-11", 120)],

    projects,
  });

  const december = calculateEmployeeMonthAvailability({
    employee: baseEmployee,

    monthKey: "2026-12",

    workCalendar: calendar("2026-12", 22),

    allocations: [allocation("A", "2026-12", 120)],

    projects,
  });

  assert(
    november.totalCapacityHours === 160,

    "Case 5 November capacity",
  );

  assert(
    november.availableHours === 40,

    "Case 5 November availability",
  );

  assert(
    december.totalCapacityHours === 176,

    "Case 5 December capacity",
  );

  assert(
    december.availableHours === 56,

    "Case 5 December availability",
  );

  /*
   * CASE 6 — FTE
   */
  const halfFteEmployee: Employee = {
    ...baseEmployee,

    employeeId: "VALIDATION_HALF_FTE",

    ftePercentage: 0.5,
  };

  const halfFte = calculateEmployeeMonthAvailability({
    employee: halfFteEmployee,

    monthKey: "2026-12",

    workCalendar: calendar("2026-12", 22),

    allocations: [
      {
        employeeId: halfFteEmployee.employeeId,

        projectId: "A",

        monthKey: "2026-12",

        allocatedHours: 40,

        source: "PROJECT_TRACK",
      },
    ],

    projects,
  });

  assert(
    halfFte.totalCapacityHours === 88,

    "Case 6 FTE capacity",
  );

  assert(
    halfFte.availableHours === 48,

    "Case 6 FTE availability",
  );

  /*
   * CASE 7 — YEAR BOUNDARY
   */
  const range = getMonthRange("2026-11", 4);

  assert(
    JSON.stringify(range) ===
      JSON.stringify(["2026-11", "2026-12", "2027-01", "2027-02"]),

    "Case 7 year-boundary month range",
  );

  /*
   * CASE 8 — UPCOMING AVAILABILITY
   */
  const transitionEmployee = baseEmployee;

  const transitionRecords = [
    calculateEmployeeMonthAvailability({
      employee: transitionEmployee,

      monthKey: "2026-11",

      workCalendar: calendar("2026-11", 20),

      allocations: [allocation("A", "2026-11", 160)],

      projects,
    }),

    calculateEmployeeMonthAvailability({
      employee: transitionEmployee,

      monthKey: "2026-12",

      workCalendar: calendar("2026-12", 22),

      allocations: [allocation("A", "2026-12", 120)],

      projects,
    }),

    calculateEmployeeMonthAvailability({
      employee: transitionEmployee,

      monthKey: "2027-01",

      workCalendar: calendar("2027-01", 22),

      allocations: [],

      projects,
    }),
  ];

  const transitions = getUpcomingAvailabilityTransitions(transitionRecords);

  assert(
    transitionRecords[0].status === "FULLY_ALLOCATED",

    "Case 8 November status",
  );

  assert(
    transitionRecords[1].status === "PARTIALLY_AVAILABLE",

    "Case 8 December status",
  );

  assert(
    transitionRecords[2].status === "AVAILABLE",

    "Case 8 January status",
  );

  assert(
    transitions.length === 2,

    "Case 8 should identify two availability transitions",
  );

  /*
   * CASE 9 — NOT YET JOINED
   */
  const futureEmployee: Employee = {
    ...baseEmployee,

    employeeId: "VALIDATION_FUTURE",

    dateOfJoining: "2027-01-15",
  };

  const futureResult = getAvailabilityForRange(
    {
      employees: [futureEmployee],

      projects,

      historicalAllocations: [],

      plannedAllocations: [],

      workCalendar: [calendar("2026-12", 22)],
    },

    "2026-12",
    1,
  );

  assert(
    futureResult.length === 0,

    "Case 9 not-yet-joined employee should not appear as available workforce",
  );

  /*
   * CASE 10 — EXITED
   */
  const exitedEmployee: Employee = {
    ...baseEmployee,

    employeeId: "VALIDATION_EXITED",

    lastWorkingDate: "2026-11-30",
  };

  const exitedResult = getAvailabilityForRange(
    {
      employees: [exitedEmployee],

      projects,

      historicalAllocations: [],

      plannedAllocations: [],

      workCalendar: [calendar("2027-01", 22)],
    },

    "2027-01",
    1,
  );

  assert(
    exitedResult.length === 0,

    "Case 10 exited employee should not appear as available workforce",
  );

  /*
   * CASE 11 — ZERO CAPACITY
   */
  const zeroCapacity = calculateEmployeeMonthAvailability({
    employee: baseEmployee,

    monthKey: "2026-10",

    workCalendar: calendar("2026-10", 0),

    allocations: [],

    projects,
  });

  assert(
    zeroCapacity.availabilityPercentage === 0,

    "Case 11 zero capacity percentage",
  );

  assert(
    Number.isFinite(zeroCapacity.availabilityPercentage),

    "Case 11 availability percentage must remain finite",
  );

  assert(
    Number.isFinite(zeroCapacity.utilizationPercentage),

    "Case 11 utilization percentage must remain finite",
  );
}
