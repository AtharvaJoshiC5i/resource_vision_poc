import type {
  Allocation,
  Employee,
  Project,
  WorkCalendar,
} from "../types/domain";

import {
  calculateEmployeeMonthAvailability,
} from "../services/availabilityService";

import {
  getProjectMonthlyEffort,
} from "../services/projectAvailabilityService";

function assert(
  condition: boolean,
  message: string,
): void {
  if (!condition) {
    throw new Error(
      `[Resource Vision] Phase 6 validation failed: ${message}`,
    );
  }
}

const employee: Employee = {
  employeeId: "PHASE6_EMP",
  employeeName: "Aarav Mehta",

  employeeStatus:
    "ACTIVE",

  dateOfJoining:
    "2024-01-01",

  primaryCapability:
    "Applied AI",

  secondaryCapability:
    "GenAI",

  department:
    "AI Solutions",

  grade: "D1",

  location:
    "Bengaluru",

  country:
    "India",

  ftePercentage: 1,
};

const projects: Project[] = [
  {
    projectId: "ALPHA",
    proposalNumber:
      "PROP-001",
    projectName:
      "Project Alpha",
    projectStatus:
      "Active",
    startDate:
      "2026-09-01",
    endDate:
      "2026-12-31",
  },

  {
    projectId: "BETA",
    proposalNumber:
      "PROP-002",
    projectName:
      "Project Beta",
    projectStatus:
      "Active",
    startDate:
      "2026-10-01",
    endDate:
      "2026-12-31",
  },
];

const decemberCalendar:
  WorkCalendar = {
    country:
      "India",

    location:
      "Bengaluru",

    monthKey:
      "2026-12",

    workingDays: 22,

    hoursPerDay: 8,

    monthlyCapacity: 176,
  };

function allocation(
  employeeId: string,
  projectId: string,
  monthKey: string,
  allocatedHours: number,
): Allocation {
  return {
    employeeId,
    projectId,
    monthKey,
    allocatedHours,
    source:
      "PROJECT_TRACK",
  };
}

export function validatePhase6(): void {
  /*
   * RESOURCE DETAIL:
   *
   * 176 capacity
   * - 80 Alpha
   * - 40 Beta
   * = 56 available
   */
  const december =
    calculateEmployeeMonthAvailability({
      employee,

      monthKey:
        "2026-12",

      workCalendar:
        decemberCalendar,

      allocations: [
        allocation(
          employee.employeeId,
          "ALPHA",
          "2026-12",
          80,
        ),

        allocation(
          employee.employeeId,
          "BETA",
          "2026-12",
          40,
        ),
      ],

      projects,
    });

  assert(
    december.totalCapacityHours ===
      176,
    "December capacity should be 176.",
  );

  assert(
    december.allocatedHours ===
      120,
    "December allocated hours should be 120.",
  );

  assert(
    december.availableHours ===
      56,
    "December available hours should be 56.",
  );

  assert(
    december.status ===
      "PARTIALLY_AVAILABLE",
    "December should be partially available.",
  );

  assert(
    december.projectAllocations.length ===
      2,
    "Both project allocations should remain visible.",
  );

  /*
   * OVER-ALLOCATION
   */
  const overAllocated =
    calculateEmployeeMonthAvailability({
      employee,

      monthKey:
        "2026-12",

      workCalendar:
        decemberCalendar,

      allocations: [
        allocation(
          employee.employeeId,
          "ALPHA",
          "2026-12",
          100,
        ),

        allocation(
          employee.employeeId,
          "BETA",
          "2026-12",
          100,
        ),
      ],

      projects,
    });

  assert(
    overAllocated.allocatedHours ===
      200,
    "Over-allocation total should be 200.",
  );

  assert(
    overAllocated.availableHours ===
      -24,
    "Over-allocation must preserve -24 available hours.",
  );

  assert(
    overAllocated.status ===
      "OVER_ALLOCATED",
    "Over-allocation status should be OVER_ALLOCATED.",
  );

  /*
   * PROJECT EFFORT:
   *
   * Alpha:
   * Aarav 80
   * Naina 120
   * = 200
   *
   * Resource count = 2
   */
  const projectAllocations: Allocation[] =
    [
      allocation(
        "PHASE6_EMP",
        "ALPHA",
        "2026-11",
        80,
      ),

      allocation(
        "NAINA",
        "ALPHA",
        "2026-11",
        120,
      ),

      allocation(
        "PHASE6_EMP",
        "ALPHA",
        "2026-12",
        80,
      ),

      allocation(
        "NAINA",
        "ALPHA",
        "2026-12",
        80,
      ),
    ];

  const novemberEffort =
    getProjectMonthlyEffort(
      projectAllocations,
      "ALPHA",
      "2026-11",
    );

  const decemberEffort =
    getProjectMonthlyEffort(
      projectAllocations,
      "ALPHA",
      "2026-12",
    );

  assert(
    novemberEffort.resourceCount ===
      2,
    "November Alpha resource count should be 2.",
  );

  assert(
    novemberEffort.totalAllocatedHours ===
      200,
    "November Alpha effort should be 200.",
  );

  assert(
    decemberEffort.resourceCount ===
      2,
    "December Alpha resource count should be 2.",
  );

  assert(
    decemberEffort.totalAllocatedHours ===
      160,
    "December Alpha effort should be 160.",
  );
}